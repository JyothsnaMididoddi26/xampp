
<?php
/* loops */

/*  while */
$x= 1;
while($x<=10){
	echo $x."<br>";
	$x= $x+1;
	//echo $x;

}


/* for loop*/
$n=array(5,7,3,4,5,6);
for($x= 0;$x<=count($n)-1;$x++){
	echo $n[$x]."<br>";

}

echo "hai";
?>

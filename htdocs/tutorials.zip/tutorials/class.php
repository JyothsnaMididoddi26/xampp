<?php 




/*
class classname
{

variables
$x==9
functions
add()



}
*/
class Add
{
	
	function add()
{
	return 5+2;
}



}
$object=new Add();
echo $object->add();
?>
<!DOCTYPE html>
<html>
<body>

<?php 
// echo "<br>";
/* ECHO "Hello World!<br>";
echo "Hello World!<br>";
EcHo "Hello World!<br>";
echo "<h1><b> heloo world</h1></b>";
*/
$txt = "Hello world!";
$x = 5;
$y = 10.5;
/* echo $txt;
echo "<br>";
echo $x;
echo "<br>";
echo $y;
*/
echo $txt."<br>".$x."<br>".$y;
$z= $x+$y;
echo $z;

/*$color = "red";
echo "My car is " . $color . "<br>";
echo "My house is " . $color . "<br>";
echo "My boat is " . $color . "<br>";
*/
?>

</body>
</html>